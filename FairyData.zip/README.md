# FAIRY DATA

Private Android app for ROM-porting fixes. Gmail login, data stored in a hidden app folder
in YOUR Google Drive, so reinstall + login restores everything.

## 1. Build the APK
Push this folder to a **private** GitHub repo. Actions → "Build APK" → download artifact `FairyData-apk`.
The log prints the SHA-1 of the signing key (needed in step 2).

## 2. One-time Google setup (needed for Gmail login)
1. console.cloud.google.com → new project
2. APIs & Services → Library → enable **Google Drive API**
3. OAuth consent screen → External → fill app name + your email → add **your Gmail as Test user**
4. Credentials → Create credentials → OAuth client ID → **Android**
   - Package name: `com.fairydata.app`
   - SHA-1: from the Actions log (step "Show SHA-1")
5. Install APK → Continue with Google → done

Notes: keystore password is in app/build.gradle.kts, so keep the repo private.
