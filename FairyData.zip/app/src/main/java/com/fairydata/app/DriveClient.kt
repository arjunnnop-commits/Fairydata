package com.fairydata.app

import android.accounts.Account
import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class HttpEx(val code: Int, msg: String) : Exception("HTTP $code $msg")

/** Minimal Google Drive v3 REST client for the appDataFolder. Call from a background thread. */
class DriveClient(private val ctx: Context, private val account: Account) {
    private val scope = "oauth2:https://www.googleapis.com/auth/drive.appdata"
    private val api = "https://www.googleapis.com/drive/v3/files"
    private val up = "https://www.googleapis.com/upload/drive/v3/files"

    private fun token(): String = GoogleAuthUtil.getToken(ctx, account, scope)

    private fun <T> call(block: (String) -> T): T {
        var t = token()
        try {
            return block(t)
        } catch (e: HttpEx) {
            if (e.code != 401) throw e
            GoogleAuthUtil.clearToken(ctx, t)
            t = token()
            return block(t)
        }
    }

    private fun open(url: String, method: String, token: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30_000
        c.readTimeout = 120_000
        c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    private fun HttpURLConnection.ok(vararg extra: Int): HttpURLConnection {
        val code = responseCode
        if (code !in 200..299 && code !in extra) {
            throw HttpEx(code, errorStream?.bufferedReader()?.readText() ?: "")
        }
        return this
    }

    /** name -> Drive file id */
    fun list(): Map<String, String> = call { t ->
        val out = HashMap<String, String>()
        var page: String? = null
        do {
            val url = "$api?spaces=appDataFolder&pageSize=1000&fields=nextPageToken,files(id,name)" +
                (page?.let { "&pageToken=$it" } ?: "")
            val c = open(url, "GET", t).ok()
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            (j.optJSONArray("files") ?: JSONArray()).objs().forEach { out[it.getString("name")] = it.getString("id") }
            page = j.optString("nextPageToken").ifEmpty { null }
        } while (page != null)
        out
    }

    fun upload(name: String, file: File, existingId: String?, mime: String): String = call { t ->
        val url = if (existingId == null) "$up?uploadType=resumable&fields=id"
        else "$up/$existingId?uploadType=resumable&fields=id"
        val meta = JSONObject().put("name", name)
        if (existingId == null) meta.put("parents", JSONArray().put("appDataFolder"))

        val c = open(url, "POST", t)
        if (existingId != null) c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        c.setRequestProperty("X-Upload-Content-Type", mime)
        c.setRequestProperty("X-Upload-Content-Length", file.length().toString())
        c.outputStream.use { it.write(meta.toString().toByteArray()) }
        c.ok()
        val loc = c.getHeaderField("Location") ?: throw HttpEx(0, "no upload location")
        c.disconnect()

        val u = open(loc, "PUT", t)
        u.doOutput = true
        u.setFixedLengthStreamingMode(file.length())
        u.setRequestProperty("Content-Type", mime)
        file.inputStream().use { i -> u.outputStream.use { o -> i.copyTo(o) } }
        u.ok()
        val id = JSONObject(u.inputStream.bufferedReader().readText()).getString("id")
        u.disconnect()
        id
    }

    fun download(id: String, dest: File) {
        call { t ->
            val c = open("$api/$id?alt=media", "GET", t).ok()
            val tmp = File(dest.path + ".tmp")
            c.inputStream.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            dest.delete()
            tmp.renameTo(dest)
            c.disconnect()
        }
    }

    fun delete(id: String) {
        call { t -> open("$api/$id", "DELETE", t).ok(404).disconnect() }
    }
}
