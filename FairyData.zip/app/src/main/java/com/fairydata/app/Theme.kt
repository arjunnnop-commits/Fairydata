package com.fairydata.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF9B8CFF), onPrimary = Color(0xFF14102E),
    secondary = Color(0xFF4DE0C8), onSecondary = Color(0xFF00201B),
    background = Color(0xFF0D0E13), onBackground = Color(0xFFE9EAF2),
    surface = Color(0xFF151720), onSurface = Color(0xFFE9EAF2),
    surfaceVariant = Color(0xFF1E2130), onSurfaceVariant = Color(0xFFA8ADC4),
    outline = Color(0xFF3A3F57), error = Color(0xFFFF6B7A)
)

@Composable
fun FairyDataTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)
