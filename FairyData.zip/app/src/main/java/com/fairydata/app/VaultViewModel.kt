package com.fairydata.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Screen {
    object Home : Screen
    data class Edit(val id: String?) : Screen
}

class VaultViewModel(app: Application) : AndroidViewModel(app) {
    var account by mutableStateOf<GoogleSignInAccount?>(null); private set
    var entries by mutableStateOf<List<Entry>>(emptyList()); private set
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)
    var screen by mutableStateOf<Screen>(Screen.Home)

    private var repo: VaultRepo? = null
    private val lock = Mutex()
    private val ctx get() = getApplication<Application>()

    init {
        val last = GoogleSignIn.getLastSignedInAccount(ctx)
        if (last != null && GoogleSignIn.hasPermissions(last, DRIVE_SCOPE)) onSignedIn(last)
    }

    fun file(name: String): File? = repo?.file(name)

    fun onSignedIn(acc: GoogleSignInAccount) {
        val a = acc.account ?: run { message = "Account not available"; return }
        val r = VaultRepo(ctx, acc.email ?: "user", DriveClient(ctx, a))
        repo = r
        account = acc
        entries = r.loadLocal()
        refresh()
    }

    fun refresh() {
        val r = repo ?: return
        viewModelScope.launch {
            busy = true
            try {
                entries = withContext(Dispatchers.IO) { lock.withLock { r.sync() } }
            } catch (e: Exception) {
                message = "Sync failed: ${e.message?.take(120)}"
            }
            busy = false
        }
    }

    private fun persist(list: List<Entry>) {
        val r = repo ?: return
        entries = list
        r.saveLocal(list)
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { lock.withLock { r.push(r.loadLocal()) } }
            } catch (e: Exception) {
                message = "Saved on phone. Will sync when online."
            }
            busy = false
        }
    }

    fun save(e: Entry) = persist((entries.filter { it.id != e.id } + e).sortedByDescending { it.updated })
    fun delete(id: String) = persist(entries.filter { it.id != id })

    fun addPhoto(uri: Uri, done: (Photo) -> Unit) {
        val r = repo ?: return
        viewModelScope.launch {
            busy = true
            try { done(withContext(Dispatchers.IO) { r.importPhoto(uri) }) }
            catch (e: Exception) { message = "Couldn't add photo" }
            busy = false
        }
    }

    fun addAttach(uri: Uri, done: (Attach) -> Unit) {
        val r = repo ?: return
        viewModelScope.launch {
            busy = true
            try { done(withContext(Dispatchers.IO) { r.importAttach(uri) }) }
            catch (e: Exception) { message = "Couldn't add file" }
            busy = false
        }
    }

    fun exportAttach(a: Attach, dest: Uri) {
        val r = repo ?: return
        viewModelScope.launch {
            busy = true
            try { withContext(Dispatchers.IO) { r.exportAttach(a, dest) }; message = "Saved to device" }
            catch (e: Exception) { message = "Export failed: ${e.message?.take(100)}" }
            busy = false
        }
    }

    fun signOut() {
        val r = repo ?: return
        if (r.isDirty()) { message = "Unsynced changes. Tap refresh first."; return }
        GoogleSignIn.getClient(ctx, gso()).signOut()
        r.wipe()
        repo = null
        account = null
        entries = emptyList()
        screen = Screen.Home
    }
}
