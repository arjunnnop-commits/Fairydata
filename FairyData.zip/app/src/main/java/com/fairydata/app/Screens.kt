@file:OptIn(ExperimentalMaterial3Api::class)

package com.fairydata.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

// ───────────────────────── helpers ─────────────────────────

fun decodeSampled(f: File, req: Int): Bitmap? {
    if (!f.exists()) return null
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (o.outWidth / (s * 2) >= req && o.outHeight / (s * 2) >= req) s *= 2
    return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
}

@Composable
fun rememberBitmap(f: File?, req: Int): ImageBitmap? {
    val st = produceState<ImageBitmap?>(null, f?.path, f?.length()) {
        value = if (f == null) null else withContext(Dispatchers.IO) { decodeSampled(f, req)?.asImageBitmap() }
    }
    return st.value
}

fun fmtSize(b: Long): String = when {
    b >= 1073741824L -> "%.1f GB".format(b / 1073741824.0)
    b >= 1048576L -> "%.1f MB".format(b / 1048576.0)
    b >= 1024L -> "${b / 1024} KB"
    else -> "$b B"
}

@Composable
fun Tag(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Surface(shape = RoundedCornerShape(8.dp), color = color.copy(alpha = 0.15f)) {
        Text(text, Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = color)
    }
}

@Composable
fun Pin(n: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondary)
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("$n", color = Color(0xFF00201B), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

// ───────────────────────── root ─────────────────────────

@Composable
fun App(vm: VaultViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (vm.account == null) LoginScreen(vm)
        else when (val s = vm.screen) {
            is Screen.Edit -> EditScreen(vm, s.id)
            else -> HomeScreen(vm)
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter))
    }
}

// ───────────────────────── login ─────────────────────────

@Composable
fun LoginScreen(vm: VaultViewModel) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            vm.onSignedIn(GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java))
        } catch (e: ApiException) {
            vm.message = if (e.statusCode == 10) "Setup error (10): check package name + SHA-1 in Google Cloud"
            else "Login failed (${e.statusCode})"
        }
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(96.dp).clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Lock, null, Modifier.size(48.dp), tint = Color(0xFF0D0E13)) }
        Spacer(Modifier.height(24.dp))
        Text("FAIRY DATA", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Your ROM fixes, screenshots and zips. Private, synced to your own Google account.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = { launcher.launch(GoogleSignIn.getClient(ctx, gso()).signInIntent) },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Continue with Google", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(14.dp))
        Text(
            "Data lives in a hidden app folder in your Google Drive. Uninstall, reinstall, log in: everything is back.",
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ───────────────────────── home ─────────────────────────

@Composable
fun HomeScreen(vm: VaultViewModel) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val list = vm.entries.filter { e ->
        (cat == null || e.category == cat) && (q.isBlank() ||
            listOf(e.title, e.device, e.rom, e.notes).any { it.contains(q, true) } ||
            e.photos.any { p -> p.props.any { it.label.contains(q, true) } } ||
            e.attachments.any { it.purpose.contains(q, true) || it.contains.contains(q, true) || it.name.contains(q, true) })
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("FAIRY DATA", fontWeight = FontWeight.Bold)
                        Text(vm.account?.email ?: "", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.refresh() }) { Icon(Icons.Default.Refresh, null) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.AccountCircle, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Sign out") }, onClick = { menu = false; vm.signOut() })
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { vm.screen = Screen.Edit(null) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("New fix") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text("Search fixes, devices, props…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = cat == null, onClick = { cat = null }, label = { Text("All") })
                CATEGORIES.forEach { c ->
                    FilterChip(selected = cat == c, onClick = { cat = if (cat == c) null else c }, label = { Text(c) })
                }
            }
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (vm.entries.isEmpty()) "No fixes yet.\nTap “New fix” to add your first one." else "Nothing matches.",
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, top = 4.dp, end = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(list, key = { it.id }) { e ->
                        EntryCard(e, e.photos.firstOrNull()?.let { vm.file(it.fileName) }) { vm.screen = Screen.Edit(e.id) }
                    }
                }
            }
        }
    }
}

@Composable
fun EntryCard(e: Entry, thumb: File?, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(onClick = onClick, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            val bmp = rememberBitmap(thumb, 300)
            Box(Modifier.size(68.dp).clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant), contentAlignment = Alignment.Center) {
                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Default.Build, null, tint = cs.onSurfaceVariant)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(e.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val sub = listOf(e.device, e.rom).filter { it.isNotBlank() }.joinToString("  •  ")
                if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tag(e.category, cs.primary)
                    if (e.photos.isNotEmpty()) Tag("${e.photos.size} photos")
                    if (e.attachments.isNotEmpty()) Tag("${e.attachments.size} files", cs.secondary)
                }
            }
        }
    }
}

// ───────────────────────── edit ─────────────────────────

@Composable
fun EditScreen(vm: VaultViewModel, id: String?) {
    val cs = MaterialTheme.colorScheme
    val isNew = id == null
    var d by remember { mutableStateOf(vm.entries.find { it.id == id } ?: Entry(id = UUID.randomUUID().toString())) }
    var openPhoto by remember { mutableStateOf<Photo?>(null) }
    var ctxEdit by remember { mutableStateOf<Attach?>(null) }
    var exporting by remember { mutableStateOf<Attach?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    BackHandler { vm.screen = Screen.Home }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addPhoto(uri) { p -> d = d.copy(photos = d.photos + p) }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addAttach(uri) { a -> d = d.copy(attachments = d.attachments + a); ctxEdit = a }
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val a = exporting
        if (uri != null && a != null) vm.exportAttach(a, uri)
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "New fix" else "Edit fix") },
                navigationIcon = { IconButton(onClick = { vm.screen = Screen.Home }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    if (!isNew) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, null, tint = cs.error) }
                    Button(
                        enabled = d.title.isNotBlank(),
                        onClick = { vm.save(d.copy(updated = System.currentTimeMillis())); vm.screen = Screen.Home },
                        modifier = Modifier.padding(end = 8.dp)
                    ) { Text("Save") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            OutlinedTextField(d.title, { d = d.copy(title = it) }, Modifier.fillMaxWidth(), label = { Text("Fix title") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(d.device, { d = d.copy(device = it) }, Modifier.weight(1f), label = { Text("Device") }, singleLine = true)
                OutlinedTextField(d.rom, { d = d.copy(rom = it) }, Modifier.weight(1f), label = { Text("ROM / port") }, singleLine = true)
            }
            Text("Category", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CATEGORIES.forEach { c -> FilterChip(selected = d.category == c, onClick = { d = d.copy(category = c) }, label = { Text(c) }) }
            }
            OutlinedTextField(d.notes, { d = d.copy(notes = it) }, Modifier.fillMaxWidth(), label = { Text("Fix steps / notes") }, minLines = 6)

            SectionHeader("Screenshots & props", "Open a photo, tap on it to drop a pin and say what applies there")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                d.photos.forEach { p -> PhotoThumb(vm.file(p.fileName), p.props.size) { openPhoto = p } }
                AddTile("Add photo") { pickPhoto.launch("image/*") }
            }

            SectionHeader("Files", "Zips, patches, anything. Add what it is for and what is inside.")
            d.attachments.forEach { a ->
                AttachCard(
                    a,
                    onEdit = { ctxEdit = a },
                    onSave = { exporting = a; saveFile.launch(a.name) },
                    onRemove = { d = d.copy(attachments = d.attachments.filter { it.id != a.id }) }
                )
            }
            OutlinedButton(onClick = { pickFile.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.AttachFile, null)
                Spacer(Modifier.width(8.dp))
                Text("Add zip / file")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    openPhoto?.let { p ->
        PhotoEditor(
            photo = p, file = vm.file(p.fileName),
            onClose = { openPhoto = null },
            onChange = { props -> d = d.copy(photos = d.photos.map { if (it.id == p.id) it.copy(props = props) else it }); openPhoto = null },
            onRemove = { d = d.copy(photos = d.photos.filter { it.id != p.id }); openPhoto = null }
        )
    }
    ctxEdit?.let { a ->
        ContextDialog(
            a, onDismiss = { ctxEdit = null },
            onSave = { purpose, contains ->
                d = d.copy(attachments = d.attachments.map { if (it.id == a.id) it.copy(purpose = purpose, contains = contains) else it })
                ctxEdit = null
            }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this fix?") },
            text = { Text("It will also be removed from your Google Drive vault.") },
            confirmButton = { TextButton(onClick = { vm.delete(d.id); vm.screen = Screen.Home }) { Text("Delete", color = cs.error) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SectionHeader(title: String, sub: String) {
    Column(Modifier.padding(top = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PhotoThumb(f: File?, pins: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bmp = rememberBitmap(f, 400)
    Box(Modifier.size(110.dp).clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant).clickable(onClick = onClick)) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (pins > 0) {
            Surface(Modifier.align(Alignment.BottomStart).padding(6.dp), shape = RoundedCornerShape(8.dp), color = cs.secondary) {
                Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, null, Modifier.size(12.dp), tint = cs.onSecondary)
                    Text("$pins", style = MaterialTheme.typography.labelSmall, color = cs.onSecondary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AddTile(label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.size(110.dp).clip(RoundedCornerShape(16.dp)).border(1.dp, cs.outline, RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.AddPhotoAlternate, null, tint = cs.primary)
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
    }
}

@Composable
fun AttachCard(a: Attach, onEdit: () -> Unit, onSave: () -> Unit, onRemove: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = cs.surface)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // context sits on top of the file
            Surface(shape = RoundedCornerShape(12.dp), color = cs.secondary.copy(alpha = 0.12f), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("FOR", style = MaterialTheme.typography.labelSmall, color = cs.secondary, fontWeight = FontWeight.Bold)
                    Text(a.purpose.ifBlank { "Add what this file is for" }, style = MaterialTheme.typography.bodyMedium,
                        color = if (a.purpose.isBlank()) cs.onSurfaceVariant else cs.onSurface)
                    Spacer(Modifier.height(8.dp))
                    Text("FIXES INSIDE", style = MaterialTheme.typography.labelSmall, color = cs.secondary, fontWeight = FontWeight.Bold)
                    Text(a.contains.ifBlank { "List the fixes inside" }, style = MaterialTheme.typography.bodyMedium,
                        color = if (a.contains.isBlank()) cs.onSurfaceVariant else cs.onSurface)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Folder, null, tint = cs.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(fmtSize(a.size), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, null) }
                IconButton(onClick = onSave) { Icon(Icons.Default.Download, null) }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, null, tint = cs.error) }
            }
        }
    }
}

@Composable
fun ContextDialog(a: Attach, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var p by remember { mutableStateOf(a.purpose) }
    var c by remember { mutableStateOf(a.contains) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("File context") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(a.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(p, { p = it }, Modifier.fillMaxWidth(), label = { Text("What is this for?") }, minLines = 2)
                OutlinedTextField(c, { c = it }, Modifier.fillMaxWidth(), label = { Text("Fixes inside") }, minLines = 3)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(p.trim(), c.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ───────────────────────── photo + props ─────────────────────────

@Composable
fun PhotoEditor(photo: Photo, file: File?, onClose: () -> Unit, onChange: (List<Prop>) -> Unit, onRemove: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bmp = rememberBitmap(file, 1800)
    var props by remember { mutableStateOf(photo.props) }
    var pending by remember { mutableStateOf<Offset?>(null) }
    var label by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
                    Text("Tap the photo to add a prop", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, null, tint = cs.error) }
                    Button(onClick = { onChange(props) }) { Text("Done") }
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (bmp != null) {
                        val ratio = bmp.width.toFloat() / bmp.height
                        BoxWithConstraints(
                            Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(14.dp))
                                .pointerInput(Unit) {
                                    detectTapGestures { o ->
                                        pending = Offset(o.x / size.width, o.y / size.height)
                                        label = ""
                                    }
                                }
                        ) {
                            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                            props.forEachIndexed { i, p ->
                                Pin(i + 1, Modifier.offset(maxWidth * p.x - 13.dp, maxHeight * p.y - 13.dp))
                            }
                        }
                    } else {
                        Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    }
                    if (props.isEmpty()) {
                        Text("No props yet. Tap anywhere on the photo and write what applies there.", color = cs.onSurfaceVariant)
                    }
                    props.forEachIndexed { i, p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Pin(i + 1)
                            Text(p.label, Modifier.weight(1f).padding(horizontal = 12.dp))
                            IconButton(onClick = { props = props.filterIndexed { j, _ -> j != i } }) { Icon(Icons.Default.Close, null) }
                        }
                    }
                }
            }
        }
    }

    pending?.let { pt ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("New prop") },
            text = { OutlinedTextField(label, { label = it }, label = { Text("What / where does this apply?") }, minLines = 2) },
            confirmButton = {
                TextButton(onClick = { props = props + Prop(pt.x, pt.y, label.trim().ifBlank { "Prop" }); pending = null }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }
}
