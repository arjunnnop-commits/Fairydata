package com.fairydata.app

import org.json.JSONArray
import org.json.JSONObject

val CATEGORIES = listOf("Boot", "Camera", "Audio", "Display", "Network", "Sensors", "Fingerprint", "Battery", "Other")

/** A pin on a photo. x/y are fractions (0..1) of the image size. */
data class Prop(val x: Float, val y: Float, val label: String)

data class Photo(val id: String, val props: List<Prop> = emptyList()) {
    val fileName: String get() = "$id.jpg"
}

data class Attach(
    val id: String,
    val name: String,
    val size: Long,
    val purpose: String = "",
    val contains: String = ""
) {
    val fileName: String get() = "$id.bin"
}

data class Entry(
    val id: String,
    val title: String = "",
    val device: String = "",
    val rom: String = "",
    val category: String = "Other",
    val notes: String = "",
    val updated: Long = System.currentTimeMillis(),
    val photos: List<Photo> = emptyList(),
    val attachments: List<Attach> = emptyList()
)

fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }

fun Entry.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("title", title); put("device", device); put("rom", rom)
    put("category", category); put("notes", notes); put("updated", updated)
    put("photos", JSONArray().also { arr ->
        photos.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("props", JSONArray().also { pa ->
                p.props.forEach { pr ->
                    pa.put(JSONObject().put("x", pr.x.toDouble()).put("y", pr.y.toDouble()).put("label", pr.label))
                }
            }))
        }
    })
    put("attachments", JSONArray().also { arr ->
        attachments.forEach { a ->
            arr.put(JSONObject().put("id", a.id).put("name", a.name).put("size", a.size)
                .put("purpose", a.purpose).put("contains", a.contains))
        }
    })
}

fun JSONObject.toEntry(): Entry = Entry(
    id = getString("id"),
    title = optString("title"),
    device = optString("device"),
    rom = optString("rom"),
    category = optString("category", "Other"),
    notes = optString("notes"),
    updated = optLong("updated"),
    photos = (optJSONArray("photos") ?: JSONArray()).objs().map { p ->
        Photo(
            p.getString("id"),
            (p.optJSONArray("props") ?: JSONArray()).objs().map {
                Prop(it.getDouble("x").toFloat(), it.getDouble("y").toFloat(), it.optString("label"))
            }
        )
    },
    attachments = (optJSONArray("attachments") ?: JSONArray()).objs().map {
        Attach(it.getString("id"), it.optString("name"), it.optLong("size"), it.optString("purpose"), it.optString("contains"))
    }
)

fun vaultJson(list: List<Entry>): String =
    JSONObject().put("entries", JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }).toString()

fun parseVault(s: String): List<Entry> =
    JSONObject(s).optJSONArray("entries")?.objs()?.map { it.toEntry() } ?: emptyList()
