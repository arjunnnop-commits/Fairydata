package com.fairydata.app

import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope

/** Hidden per-app folder in the user's own Google Drive. Only this app can see it. */
val DRIVE_SCOPE = Scope("https://www.googleapis.com/auth/drive.appdata")

fun gso(): GoogleSignInOptions =
    GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestScopes(DRIVE_SCOPE)
        .build()
