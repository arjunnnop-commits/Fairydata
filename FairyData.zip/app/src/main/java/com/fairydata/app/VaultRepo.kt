package com.fairydata.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID

/** Local cache (filesDir) + sync with Drive appDataFolder. Call from a background thread. */
class VaultRepo(private val ctx: Context, email: String, private val drive: DriveClient) {
    private val dir = File(ctx.filesDir, "vault_" + email.hashCode().toString().replace('-', 'n')).apply { mkdirs() }
    private val vaultFile get() = File(dir, "vault.json")
    private val dirty get() = File(dir, "dirty")

    fun file(name: String) = File(dir, name)
    fun isDirty() = dirty.exists()
    fun wipe() { dir.deleteRecursively() }

    fun loadLocal(): List<Entry> =
        if (vaultFile.exists()) runCatching { parseVault(vaultFile.readText()) }.getOrDefault(emptyList()) else emptyList()

    fun saveLocal(entries: List<Entry>) {
        vaultFile.writeText(vaultJson(entries))
        dirty.writeText("1")
        val refs = refs(entries)
        dir.listFiles()?.forEach { f ->
            if (f.name != "vault.json" && f.name != "dirty" && f.name !in refs) f.delete()
        }
    }

    private fun refs(entries: List<Entry>): Set<String> =
        entries.flatMap { e -> e.photos.map { it.fileName } + e.attachments.map { it.fileName } }.toSet()

    /** If there are unsynced local changes, push them; otherwise pull from Drive. */
    fun sync(): List<Entry> {
        if (isDirty()) { push(loadLocal()); return loadLocal() }
        val remote = drive.list()
        remote["vault.json"]?.let { drive.download(it, vaultFile) }
        val entries = loadLocal()
        entries.flatMap { it.photos }.forEach { p ->
            if (!file(p.fileName).exists()) remote[p.fileName]?.let { drive.download(it, file(p.fileName)) }
        }
        return entries
    }

    fun push(entries: List<Entry>) {
        val remote = drive.list()
        val refs = refs(entries)
        refs.forEach { n ->
            val f = file(n)
            if (f.exists() && n !in remote) drive.upload(n, f, null, if (n.endsWith(".jpg")) "image/jpeg" else "application/octet-stream")
        }
        vaultFile.writeText(vaultJson(entries))
        drive.upload("vault.json", vaultFile, remote["vault.json"], "application/json")
        remote.forEach { (n, id) -> if (n != "vault.json" && n !in refs) drive.delete(id) }
        dirty.delete()
    }

    fun importPhoto(uri: Uri): Photo {
        val id = UUID.randomUUID().toString()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / s > 2000 || bounds.outHeight / s > 2000) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        file("$id.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        bmp.recycle()
        return Photo(id)
    }

    fun importAttach(uri: Uri): Attach {
        val id = UUID.randomUUID().toString()
        var name = "file"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (n >= 0) name = c.getString(n) ?: name
            }
        }
        val dest = file("$id.bin")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { i.copyTo(it) } }
        return Attach(id, name, dest.length())
    }

    fun exportAttach(a: Attach, dest: Uri) {
        val f = file(a.fileName)
        if (!f.exists()) drive.list()[a.fileName]?.let { drive.download(it, f) }
        check(f.exists()) { "File not found on Drive" }
        ctx.contentResolver.openOutputStream(dest)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    }
}
